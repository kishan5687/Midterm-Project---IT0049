<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>POS - Customer Registry</title>
    <link rel="stylesheet" href="https://jsdelivr.net">
</head>
<body class="bg-light">
    <div class="container my-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>👥 Customer Registry Desk</h2>
            <a href="<?= base_url('/') ?>" class="btn btn-secondary">◀ Back to Menu</a>
        </div>

        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
        <?php endif; ?>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="card p-3 shadow-sm">
                    <h5>Register New Customer</h5>
                    <form action="<?= base_url('customers/store') ?>" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="full_name" class="form-control" required autocomplete="off">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="email" class="form-control" required autocomplete="off">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Phone Contact Line</label>
                            <input type="text" name="phone" class="form-control" autocomplete="off">
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Save Customer File</button>
                    </form>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card p-3 shadow-sm">
                    <h5>Registered Client Directory</h5>
                    <table class="table table-striped table-bordered align-middle mt-2">
                        <thead class="table-dark">
                            <tr>
                                <th>Name Handle</th>
                                <th>Email Address</th>
                                <th>Phone Line</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($customers)): ?>
                                <tr><td colspan="4" class="text-center text-muted">No client records logged yet.</td></tr>
                            <?php else: ?>
                                <?php foreach($customers as $c): ?>
                                <tr>
                                    <td><strong><?= esc($c['full_name']) ?></strong></td>
                                    <td><?= esc($c['email']) ?></td>
                                    <td><?= esc($c['phone'] ?: 'None') ?></td>
                                    <td>
                                        <a href="<?= base_url('customers/delete/' . $c['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Erase customer file?')">Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
