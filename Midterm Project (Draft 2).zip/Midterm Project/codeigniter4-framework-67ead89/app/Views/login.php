<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>POS System - Login</title>
    <!-- Bootstrap 5 for layout structure -->
    <link rel="stylesheet" href="https://jsdelivr.net">
    <!-- FontAwesome for the input field icons -->
    <link rel="stylesheet" href="https://cloudflare.com">
    
    <style>
        * {
            box-sizing: border-box; /* Prevents fields from stretching beyond margins */
        }
        body {
            background-color: #f4f4f2; /* Changed background to a clean dirty white / off-white */
            display: flex;             /* Force pure flex layout on the whole screen */
            justify-content: center;   /* Center horizontally */
            align-items: center;       /* Center vertically */
            height: 100vh;             /* Lock full screen height */
            margin: 0;
            padding: 0;
            font-family: sans-serif;
        }
        .login-container {
            position: relative;
            background-color: #e9ecef; /* Clean light gray card background */
            border-radius: 40px;       /* Smooth rounded container edges */
            padding: 60px 35px 35px 35px;
            width: 380px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.08); /* Soft drop shadow */
        }
        .avatar-box {
            position: absolute;
            top: -50px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 100px;
            background-color: #ffffff;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.05);
            border: 1px solid #e9ecef;
        }
        .avatar-box i {
            font-size: 50px;
            color: #6c757d;            /* Clean neutral gray icon color */
        }
        .custom-input-group {
            position: relative;
            margin-bottom: 20px;
            width: 100%;
        }
        .custom-input {
            border-radius: 50px !important; /* Pill-shaped fields */
            border: 1px solid #ced4da;
            padding: 12px 45px 12px 20px;
            font-size: 15px;
            background-color: #ffffff;      /* Pure white field background */
            width: 100%;
            color: #333333;                 /* Clear contrast for visibility */
        }
        .custom-input::placeholder {
            color: #a0a0a0;                 
        }
        .input-icon {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: #707070;
            z-index: 10;
        }
        .btn-login {
            background-color: #495057; /* Charcoal button to stand out beautifully on gray/white */
            color: #ffffff;
            border-radius: 50px;
            padding: 12px;
            font-weight: bold;
            letter-spacing: 1px;
            border: none;
            transition: 0.2s;
            width: 100%;
        }
        .btn-login:hover {
            background-color: #343a40;
            color: #ffffff;
        }
        .forgot-link {
            color: #6c757d;                 /* Subdued gray link */
            text-decoration: none;
            font-size: 14px;
            display: block;
            text-align: center;
            margin-top: 20px;
        }
        .forgot-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="login-container">
        
        <!-- Circular User Profile Header Icon -->
        <div class="avatar-box">
            <i class="fa-solid fa-user"></i>
        </div>

        <!-- Error Alerts Panel -->
        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger py-2 rounded-4 text-center mt-2" style="font-size: 14px;">
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>

        <form action="<?= base_url('login/authenticate') ?>" method="POST" class="mt-4">
            
            <!-- User ID Field -->
            <div class="custom-input-group">
                <input type="text" name="username" class="form-control custom-input" placeholder="User ID" required autocomplete="off">
                <i class="fa-solid fa-user input-icon"></i>
            </div>

            <!-- Password Field -->
            <div class="custom-input-group">
                <input type="password" name="password" class="form-control custom-input" placeholder="Password" required>
                <i class="fa-solid fa-lock input-icon"></i>
            </div>

            <!-- Submit Action Trigger -->
            <button type="submit" class="btn btn-login">LOGIN</button>

            <!-- Footer Context Helper Text Link -->
            <a href="#" class="forgot-link">Forgot Password?</a>
            
        </form>
    </div>

</body>
</html>
