<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');

// Authentication Routes
$routes->get('login', 'AuthController::login');
$routes->post('login/authenticate', 'AuthController::authenticate');
$routes->get('logout', 'AuthController::logout');

// Dashboard & POS Core (Protected routes should ideally use a filter later)
$routes->get('/', 'DashboardController::index');

// CRUD Management Routes
$routes->presenter('products', ['controller' => 'ProductController']);
$routes->presenter('customers', ['controller' => 'CustomerController']);
$routes->presenter('staff', ['controller' => 'UserController']);

// Sales Workflow Routes
$routes->get('sales/create', 'SaleController::create');
$routes->post('sales/store', 'SaleController::store');
$routes->get('sales', 'SaleController::index');
$routes->get('setup', 'SetupController::index');

// Core Dashboard Root Map
$routes->get('/', 'Home::index');

// Products Module Routing Engine
$routes->get('products', 'ProductController::index');
$routes->post('products/store', 'ProductController::store');
$routes->get('products/delete/(:num)', 'ProductController::delete/$1');

// Customers Module Routing Engine
$routes->get('customers', 'CustomerController::index');
$routes->post('customers/store', 'CustomerController::store');
$routes->get('customers/delete/(:num)', 'CustomerController::delete/$1');

// Sales Workflow Routing Engine
$routes->get('sales', 'SaleController::index');
$routes->post('sales/store', 'SaleController::store');
