<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        if (!session()->has('logged_in')) {
            return redirect()->to('login');
        }

        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>POS System - Dashboard</title>
            <link rel="stylesheet" href="https://jsdelivr.net">
        </head>
        <body class="bg-light">
            <nav class="navbar navbar-dark bg-dark px-4">
                <span class="navbar-brand mb-0 h1">📦 POS System Workspace</span>
                <span class="navbar-text text-white">
                    Welcome, <strong><?= session()->get('full_name') ?></strong> | 
                    <a href="<?= base_url('logout') ?>" class="btn btn-sm btn-danger ms-2">Logout</a>
                </span>
            </nav>

            <div class="container my-5">
                <h2 class="mb-4 text-secondary">Main Modules Menu</h2>
                <div class="row g-4">
                    <div class="col-md-4">
                        <div class="card shadow-sm h-100">
                            <div class="card-body text-center">
                                <h5 class="card-title">Product Catalog</h5>
                                <p class="card-text text-muted">Manage items, tracking inventory levels, prices, and system images.</p>
                                <a href="<?= base_url('products') ?>" class="btn btn-primary w-100">Open Products CRUD</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card shadow-sm h-100">
                            <div class="card-body text-center">
                                <h5 class="card-title">Customer Register</h5>
                                <p class="card-text text-muted">Add, view, and modify client profile records and communication handles.</p>
                                <a href="<?= base_url('customers') ?>" class="btn btn-primary w-100">Open Customers CRUD</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card shadow-sm h-100">
                            <div class="card-body text-center">
                                <h5 class="card-title">Sales Counter</h5>
                                <p class="card-text text-muted">Process real-time transactions, auto-deduct items, and pull history logs.</p>
                                <a href="<?= base_url('sales') ?>" class="btn btn-success w-100">Go to Sales Workflow</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>
        <?php
    }
}
