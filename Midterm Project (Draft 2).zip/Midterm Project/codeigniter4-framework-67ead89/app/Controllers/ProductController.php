<?php

namespace App\Controllers;

use App\Models\ProductModel;

class ProductController extends BaseController
{
    // 1. Read / List all items
    public function index()
    {
        if (!session()->has('logged_in')) return redirect()->to('login');
        
        $model = new ProductModel();
        $data['products'] = $model->findAll();
        return view('products/index', $data);
    }

    // 2. Process product creation with image file saving
    public function store()
    {
        if (!session()->has('logged_in')) return redirect()->to('login');
        
        $model = new ProductModel();
        $imageName = null;

        $file = $this->request->getFile('image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Generate a random clean name so files never overwrite each other
            $imageName = $file->getRandomName();
            $file->move('uploads/', $imageName);
        }

        $model->insert([
            'name'           => $this->request->getPost('name'),
            'price'          => $this->request->getPost('price'),
            'stock_quantity' => $this->request->getPost('stock_quantity'),
            'image'          => $imageName,
            'created_at'     => date('Y-m-d H:i:s')
        ]);

        return redirect()->to('products')->with('success', 'Product registered successfully!');
    }

    // 3. Delete an item record
    public function delete($id)
    {
        if (!session()->has('logged_in')) return redirect()->to('login');
        
        $model = new ProductModel();
        $model->delete($id);
        return redirect()->to('products')->with('success', 'Product removed from system.');
    }
}
