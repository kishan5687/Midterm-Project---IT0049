<?php

namespace App\Controllers;

use App\Models\SaleModel;
use App\Models\ProductModel;
use App\Models\CustomerModel;

class SaleController extends BaseController
{
    // Display Checkout Workspace & Sales Logs
    public function index()
    {
        if (!session()->has('logged_in')) return redirect()->to('login');

        $saleModel     = new SaleModel();
        $productModel  = new ProductModel();
        $customerModel = new CustomerModel();

        // Feed dropdown selectors and history panels
        $data['sales']     = $saleModel->getSalesHistory();
        $data['products']  = $productModel->where('stock_quantity >', 0)->findAll();
        $data['customers'] = $customerModel->findAll();

        return view('sales/index', $data);
    }

    // Process Transaction Workflow
    public function store()
    {
        if (!session()->has('logged_in')) return redirect()->to('login');

        $saleModel    = new SaleModel();
        $productModel = new ProductModel();

        $productId  = $this->request->getPost('product_id');
        $customerId = $this->request->getPost('customer_id') ?: null; // Optional selection field
        $quantity   = intval($this->request->getPost('quantity'));

        // Load the specific item to run security checks
        $product = $productModel->find($productId);

        if (!$product) {
            return redirect()->to('sales')->with('error', 'Selected item does not exist.');
        }

        // Strict validation block: Stop execution if stock is insufficient
        if ($product['stock_quantity'] < $quantity) {
            return redirect()->to('sales')->with('error', 'Transaction Cancelled: Insufficient stock. Only ' . $product['stock_quantity'] . ' items remain.');
        }

        // Calculate checkout metrics
        $totalPrice = $product['price'] * $quantity;

        // Step A: Insert data into the sales transaction history table
        $saleModel->insert([
            'product_id'  => $productId,
            'customer_id' => $customerId,
            'sold_by'     => session()->get('user_id'), // Grab ID from current session
            'quantity'    => $quantity,
            'total_price' => $totalPrice,
            'created_at'  => date('Y-m-d H:i:s')
        ]);

        // Step B: Deduct purchased items from the available product stock counter
        $newStock = $product['stock_quantity'] - $quantity;
        $productModel->update($productId, ['stock_quantity' => $newStock]);

        return redirect()->to('sales')->with('success', 'Transaction cleared successfully! Inventory levels adjusted.');
    }
}
