<?php

namespace App\Controllers;

use App\Models\UserModel;

class AuthController extends BaseController
{
    // Display the login view interface
    public function login()
    {
        // If already logged in, redirect straight to dashboard home
        if (session()->has('logged_in')) {
            return redirect()->to('/');
        }
        return view('login');
    }

    // Process submission credentials
    public function authenticate()
    {
        $session = session();
        $userModel = new UserModel();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        // Search for user in database
        $user = $userModel->where('username', $username)->first();

        if ($user) {
            // Verify password using native PHP password_hash comparison
            if (password_verify($password, $user['password'])) {
                // Set session data fields
                $session->set([
                    'user_id'   => $user['id'],
                    'username'  => $user['username'],
                    'full_name' => $user['full_name'],
                    'logged_in' => true
                ]);
                return redirect()->to('/');
            }
        }

        // Return with error flash data message if login fails
        $session->setFlashdata('error', 'Invalid username or password.');
        return redirect()->to('login');
    }

    // Terminate session on log out
    public function logout()
    {
        session()->destroy();
        return redirect()->to('login');
    }
}
