<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');

// Authentication Routes
$routes->get('login', 'AuthController::login');
$routes->post('login/authenticate', 'AuthController::authenticate');
$routes->get('logout', 'AuthController::logout');

// Dashboard & POS Core (Protected routes should ideally use a filter later)
$routes->get('/', 'DashboardController::index');

// CRUD Management Routes
$routes->presenter('products', ['controller' => 'ProductController']);
$routes->presenter('customers', ['controller' => 'CustomerController']);
$routes->presenter('staff', ['controller' => 'UserController']);

// Sales Workflow Routes
$routes->get('sales/create', 'SaleController::create');
$routes->post('sales/store', 'SaleController::store');
$routes->get('sales', 'SaleController::index');
