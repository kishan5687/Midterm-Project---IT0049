<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table            = 'products';
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['name', 'price', 'stock_quantity', 'image', 'created_at'];
    protected $useTimestamps    = false; // Handled manually or via standard DATETIME inserts
}
